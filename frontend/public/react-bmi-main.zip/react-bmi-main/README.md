# BMI Calculator made with React JS

![Page preview](/src/img/preview.png)

You can access the final result here: [BMI Calculator](https://ldequadra.github.io/react-bmi/)

## Credits

This project was made following a tutorial by [Sujeito Programador](https://youtu.be/K-8YYSEYaB8)

## Contributing

Pull requests are welcome. 😀 <br>
This is a work in progress and also provides me more knowledge.